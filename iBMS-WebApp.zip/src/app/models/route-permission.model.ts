import { RoutePermissionType } from '../shared';

export class RoutePermission {

    constructor(
        public roles: Array<string>,
        public permissionType: RoutePermissionType
    ) { }

    static factory(roles: Array<string>, permissionType: RoutePermissionType): RoutePermission {
        return new RoutePermission(roles, permissionType);
    }
}
