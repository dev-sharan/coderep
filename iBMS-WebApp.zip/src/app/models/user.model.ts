export class UserModel {
  id: number;
  fullName: string;
  firstName: string;
  lastName: string;
  userName: string;
  email: string;
  phone: string;
  role: string;
}
