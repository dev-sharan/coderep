import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

// interfaces & models
import { INavigationItem } from './../interfaces';

@Component({
  selector: 'app-left-navigation',
  templateUrl: './left-navigation.component.html',
  styleUrls: ['./left-navigation.component.scss']
})
export class LeftNavigationComponent implements OnInit {

  public navigationItems: Array<INavigationItem> = [];

  constructor(private router: Router) { }

  ngOnInit() {
    this.navigationItems = [
      {
        name: 'Dashboard',
        link: './dashboard',
        index: 0,
        activeImage: null,
        inactiveImage: null
      },
      {
        name: 'Master Data',
        link: './master-data',
        index: 1,
        activeImage: null,
        inactiveImage: null,
        subMenu: [
          {
            name: 'My Company Details',
            link: './master-data/my-company',
            index: 0
          },
          {
            name: 'Client/Customer Details',
            link: './master-data/customer-details',
            index: 1
          },
          {
            name: 'Vendor Details',
            link: './master-data/vendor-details',
            index: 2
          },
          {
            name: 'Item/Service Details',
            link: './master-data/item-details',
            index: 3
          }
        ]
      },
      {
        name: 'Sales',
        link: './sales',
        index: 2,
        activeImage: null,
        inactiveImage: null
      },
      {
        name: 'Purchases',
        link: './purchases',
        index: 3,
        activeImage: null,
        inactiveImage: null,
        subMenu: [
          {
            name: 'purchase invoices',
            link: './purchases/purchase-invoice',
            index: 0
          },
          {
            name: 'payments',
            link: './purchases/payments',
            index: 1
          }
        ]
      },
      {
        name: 'Expenses',
        link: './expenses',
        index: 4,
        activeImage: null,
        inactiveImage: null
      },
      {
        name: 'Bank Transactions',
        link: './bank-transactions',
        index: 5,
        activeImage: null,
        inactiveImage: null
      }
    ];
  }

  public goToPage(page) {
    this.router.navigate([page]);
  }

}
