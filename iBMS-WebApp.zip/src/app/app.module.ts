import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgProgressComponent } from '@ngx-progressbar/core';
// modules
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
// components
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LeftNavigationComponent } from './left-navigation/left-navigation.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LeftNavigationComponent
  ],
  imports: [
    BrowserModule,
    SharedModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  providers: [NgProgressComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
