import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MasterDataRoutingModule } from './master-data-routing.module';
import { MasterDataComponent } from './master-data.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { VendorDetailsComponent } from './vendor-details/vendor-details.component';
import { MyCompanyDetailsComponent } from './my-company-details/my-company-details.component';
import { ItemDetailsComponent } from './item-details/item-details.component';

@NgModule({
  imports: [
    CommonModule,
    MasterDataRoutingModule
  ],
  declarations: [
    MasterDataComponent,
    CustomerDetailsComponent,
    VendorDetailsComponent,
    MyCompanyDetailsComponent,
    ItemDetailsComponent
  ]
})
export class MasterDataModule { }
