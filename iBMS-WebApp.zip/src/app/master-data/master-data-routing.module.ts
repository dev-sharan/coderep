import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// components
import { MasterDataComponent } from './master-data.component';
import { MyCompanyDetailsComponent } from './my-company-details/my-company-details.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { VendorDetailsComponent } from './vendor-details/vendor-details.component';
import { ItemDetailsComponent } from './item-details/item-details.component';

const routes: Routes = [
  {
    path: '',
    component: MasterDataComponent,
    children: [
      { path: '', redirectTo: 'my-company', pathMatch: 'full'},
      { path: 'my-company', component: MyCompanyDetailsComponent },
      { path: 'customer-details', component: CustomerDetailsComponent },
      { path: 'vendor-details', component: VendorDetailsComponent },
      { path: 'item-details', component: ItemDetailsComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterDataRoutingModule { }
