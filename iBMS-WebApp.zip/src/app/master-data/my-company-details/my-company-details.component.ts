import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-company-details',
  templateUrl: './my-company-details.component.html',
  styleUrls: ['./my-company-details.component.scss']
})
export class MyCompanyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
