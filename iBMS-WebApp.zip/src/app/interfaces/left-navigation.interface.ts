export interface INavigationItem {
  name: string;
  link: string;
  index: number;
  activeImage?: string;
  inactiveImage?: string;
  subMenu?: Array<INavigationItem>;
}
