import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AuthorizationService } from '../../services';
import { AuthorizationResult } from '../../shared/config';

/**
 * Class validates the token , If authenticated redirect it to the specified path else force the application
 * back to login page
 */
@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private authorizeService: AuthorizationService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (route.data.routePermission) {
      const result: AuthorizationResult = this.authorizeService.authorize(route.data.routePermission);

      // if user is un-authorized
      if (result === AuthorizationResult.Unauthorised) {
        this.router.navigate(['/']);
        return false;
      }

      // if user is not logged-in
      if (result === AuthorizationResult.LoginRequired) {
        this.router.navigate(['/account'], {
          queryParams: {
            returnUrl: state.url
          }
        });
        return false;
      }

      return true;
    }
  }
}
