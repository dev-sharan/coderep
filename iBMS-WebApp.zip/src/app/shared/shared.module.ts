import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatSidenavModule,
  MatExpansionModule,
  MatListModule
} from '@angular/material';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { NgProgressModule } from '@ngx-progressbar/core';

import { AuthGuard } from './guards/auth.guard';
import { RequestInterceptor } from './interceptors/request.interceptor';
import { ResponseInterceptor } from './interceptors/response.interceptor';

@NgModule({
  imports: [
    ToastrModule.forRoot(),
    NgProgressModule.forRoot(),
    CommonModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatExpansionModule,
    MatListModule
  ],
  declarations: [],
  exports: [
    ToastrModule,
    NgProgressModule,
    HttpClientModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatExpansionModule,
    MatListModule
  ],
  providers: [
    AuthGuard,
    ToastrService,
    { provide: HTTP_INTERCEPTORS, useClass: RequestInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ResponseInterceptor, multi: true },
],
})
export class SharedModule { }
