import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { NgProgressComponent } from '@ngx-progressbar/core';

@Injectable()
export class RequestInterceptor implements HttpInterceptor {
  constructor(private progress: NgProgressComponent) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.progress.start();
    console.log(`Intercepting HttpRequest of type ${req.method} to url ${req.url}`);
    /**
     * Skip the interceptor for authentication requests
     * https://github.com/angular/angular/issues/20203
     * https://github.com/angular/angular/issues/18155
     */
    if (!!req.headers.get('Skip-Auth')) {
      console.log('Hit the passthrough for requests that doesnot require authentication');
      return next.handle(req).pipe(finalize(() => this.progress.complete()));
    }

    // Clone the request to add the new header.
    const authReq = req.clone({ headers: req.headers.set('withCredentials', 'true') });
    // Pass on the cloned request instead of the original request.
    return next.handle(authReq).pipe(finalize(() => this.progress.complete()));
  }
}
