
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError as observableCatchError } from 'rxjs/operators';
import { throwError as observableThrowError, Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

import { StorageService } from '../../services';
import { Config } from '../../shared/config';

@Injectable()
export class ResponseInterceptor implements HttpInterceptor {
    constructor(
        private router: Router,
        private toastr: ToastrService,
        private storageService: StorageService,
    ) { }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
        return next.handle(req)
        .pipe(
            observableCatchError(this._handleError.bind(this))
        );
    }

    private _handleError(err: HttpErrorResponse) {
        if (err.status === 401) {
            this.storageService.clearAll(Config.localstorage);
            this.router.navigate(['/account']);
            this.toastr.error('Authorization has been denied for this request.');
            return;
        } else if (err.status === 403) { // windows-auth un-authorized check
            this.router.navigate(['/']);
            return;
        } else {
            if (err.error instanceof Error) {
                // A client-side or network error occurred. Handle it accordingly.
                console.error('err.error instanceof Error:' + err.error.message);
                this.toastr.error(err.statusText);
            } else if (err.error instanceof ProgressEvent) {
                // A client-side or network error occurred. Handle it accordingly.
                console.error('err.error instanceof ProgressEvent:' + err.message);
                this.toastr.error(err.statusText);
            } else {
                // The backend returned an unsuccessful response code.
                if (err.error && typeof (err.error) === 'object') {
                    if (err.error.length > 0) { // if its an array of errors
                        (err.error).forEach((message: string) => {
                            console.log(`Backend returned code ${err.status} body was: ${message}`);
                            this.toastr.error(message);
                        });
                    } else { // token specific errors
                        console.log(`Backend returned code ${err.status} body was: ${err.error.error_description}`);
                        this.toastr.error(err.error.error_description);
                    }
                } else {
                    console.log(`Backend returned code ${err.status} body was: ${err.error}`);
                    this.toastr.error(err.error);
                }
            }
        }

        return observableThrowError({
            'status': err.status,
            'message': ((err.error instanceof Error || err.error instanceof ProgressEvent) ? err.statusText : err.error)
        });
    }
}
