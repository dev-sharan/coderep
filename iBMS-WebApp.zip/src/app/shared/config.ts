import { environment } from '../../environments/environment';

export enum RoutePermissionType {
  AtLeastOneRole = 1,
  AllRole = 2,
  OnlyLoginRequired = 3
}

export enum AuthorizationResult {
  Success = 1,
  LoginRequired = 2,
  Unauthorised = 3
}

export const URLs = {
  // common
  login: `${environment.baseUrl}/api/GetCurrentUser`,
  dashboard: `${environment.baseUrl}/api/GetDashboardDetails`,
};

export const Config = {
  user: 'user',
  localstorage: 'localStorage',
  welcomeMsg: 'Welcome to iBMS app!',
  morningMsg: 'Good morning',
  afternoonMsg: 'Good afternoon',
  eveningMsg: 'Good evening'
};
