import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PurchasesComponent } from './purchases.component';
import { PurchaseInvoiceComponent } from './purchase-invoice/purchase-invoice.component';
import { PaymentsComponent } from './payments/payments.component';

const routes: Routes = [
  {
    path: '',
    component: PurchasesComponent,
    children: [
      { path: '', redirectTo: 'purchase-invoice', pathMatch: 'full'},
      { path: 'purchase-invoice', component: PurchaseInvoiceComponent },
      { path: 'payments', component: PaymentsComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PurchasesRoutingModule { }
