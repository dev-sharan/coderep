import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PurchasesRoutingModule } from './purchases-routing.module';
import { PurchaseInvoiceComponent } from './purchase-invoice/purchase-invoice.component';
import { PaymentsComponent } from './payments/payments.component';
import { PurchasesComponent } from './purchases.component';


@NgModule({
  imports: [
    CommonModule,
    PurchasesRoutingModule
  ],
  declarations: [PurchaseInvoiceComponent, PaymentsComponent, PurchasesComponent]
})
export class PurchasesModule { }
