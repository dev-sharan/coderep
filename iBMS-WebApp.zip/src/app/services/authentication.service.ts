import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import {map} from 'rxjs/operators';

// components
import { URLs, Config } from '../shared/config';
// services
import { StorageService } from './storage.service';
// interfaces and models
import { UserModel } from '../models';

@Injectable()
export class AuthenticationService {
  private userInfo: UserModel;
  public isLoggedInEvent = new BehaviorSubject<any>(false);
  isLoggedInEvent$ = this.isLoggedInEvent.asObservable();

  constructor(
    private http: HttpClient,
    private storageService: StorageService
  ) {}

  authenticateUser(): Observable<boolean> {
    return this.http.get<UserModel>(URLs.login).pipe(
      map((user: UserModel) => {
        this.userInfo = user;
        this.storageService.setItem(Config.user, this.userInfo, Config.localstorage);
        this.isLoggedInEvent.next(true);
        return true;
      })
    );
  }
}
