import { Injectable } from '@angular/core';

@Injectable()
export class StorageService {

  constructor() { }

  getItem(key: string, type: string): any {
    switch (type) {
      case 'localStorage':
        return JSON.parse(localStorage.getItem(key));
      case 'sessionStorage':
        return JSON.parse(sessionStorage.getItem(key));
      default:
        return null;
    }
  }

  setItem(key: string, value: any, type: string): void {
    let store = null;
    switch (type) {
      case 'localStorage':
        store = localStorage;
        store.setItem(key, JSON.stringify(value));
        break;
      case 'sessionStorage':
        store = sessionStorage;
        store.setItem(key, JSON.stringify(value));
        break;

    }
  }

  removeItem(key: string, type: string): void {
    switch (type) {
      case 'localStorage':
        localStorage.removeItem(key);
        break;
      case 'sessionStorage':
        sessionStorage.removeItem(key);
        break;
    }
  }

  clearAll(type: string): void {
    switch (type) {
      case 'localStorage':
        localStorage.clear();
        break;
      case 'sessionStorage':
        sessionStorage.clear();
        break;
    }
  }
}

