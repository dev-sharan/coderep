import { Injectable } from '@angular/core';

import { StorageService } from './storage.service';
import { UserModel } from '../models';
import { RoutePermission } from '../models';
import { AuthorizationResult, Config, RoutePermissionType } from '../shared/config';

@Injectable()
export class AuthorizationService {

  constructor(private storageService: StorageService) { }

  authorize(routePermission: RoutePermission): AuthorizationResult {
    let isAuthorised = false;
    const user: UserModel = this.storageService.getItem(Config.user, Config.localstorage);

    if (user === null) { return AuthorizationResult.LoginRequired; }

    if (routePermission.permissionType === RoutePermissionType.OnlyLoginRequired) {
      isAuthorised = true;
    } else if (routePermission.permissionType === RoutePermissionType.AtLeastOneRole) {
      isAuthorised = routePermission.roles.some((allowedRole: string) => allowedRole.toLowerCase() === user.role.toLowerCase());
    } else if (routePermission.permissionType === RoutePermissionType.AllRole) {
      isAuthorised = routePermission.roles.some((allowedRole: string) => allowedRole.toLowerCase() === user.role.toLowerCase());
    }

    if (isAuthorised) {
      return AuthorizationResult.Success;
    } else {
      return AuthorizationResult.Unauthorised;
    }
  }
}
