import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-forbiddon-error',
  templateUrl: './page-forbiddon-error.component.html',
  styleUrls: ['./page-forbiddon-error.component.css']
})
export class PageForbiddonErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
