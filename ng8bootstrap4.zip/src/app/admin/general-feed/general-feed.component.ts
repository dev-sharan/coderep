import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-general-feed',
  templateUrl: './general-feed.component.html',
  styleUrls: ['./general-feed.component.css']
})
export class GeneralFeedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
