import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ui-elements',
  templateUrl: './ui-elements.component.html',
  styleUrls: ['./ui-elements.component.css']
})
export class UiElementsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
