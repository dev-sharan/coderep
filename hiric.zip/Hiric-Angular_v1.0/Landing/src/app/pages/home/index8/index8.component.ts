import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index8',
  templateUrl: './index8.component.html',
  styleUrls: ['./index8.component.css']
})
export class Index8Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
