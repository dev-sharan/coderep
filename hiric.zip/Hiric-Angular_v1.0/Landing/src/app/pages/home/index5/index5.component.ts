import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index5',
  templateUrl: './index5.component.html',
  styleUrls: ['./index5.component.css']
})
export class Index5Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
