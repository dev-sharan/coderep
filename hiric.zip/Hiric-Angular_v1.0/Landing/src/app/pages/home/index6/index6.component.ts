import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index6',
  templateUrl: './index6.component.html',
  styleUrls: ['./index6.component.css']
})
export class Index6Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
