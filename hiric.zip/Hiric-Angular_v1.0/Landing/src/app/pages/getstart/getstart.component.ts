import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getstart',
  templateUrl: './getstart.component.html',
  styleUrls: ['./getstart.component.css']
})
export class GetstartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
