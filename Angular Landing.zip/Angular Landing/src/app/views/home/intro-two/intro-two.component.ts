import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intro-two',
  templateUrl: './intro-two.component.html',
  styleUrls: ['./intro-two.component.scss']
})
export class IntroTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
