export const environment = {
  production: true,
  apiURL: 'productionApi'
};
