import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-level3',
  templateUrl: './third-level3.component.html'
})
export class ThirdLevel3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
