import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-level2',
  templateUrl: './third-level2.component.html'
})
export class ThirdLevel2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
