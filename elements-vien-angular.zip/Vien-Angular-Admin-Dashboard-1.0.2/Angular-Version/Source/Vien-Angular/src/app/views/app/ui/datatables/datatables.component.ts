import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datatables',
  templateUrl: './datatables.component.html'
})
export class DatatablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
