import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-levels',
  templateUrl: './menu-levels.component.html'
})
export class MenuLevelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
