import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miscellaneous',
  templateUrl: './miscellaneous.component.html'
})
export class MiscellaneousComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
