import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-cards',
  templateUrl: './user-cards.component.html'
})
export class UserCardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
