import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-card-list',
  templateUrl: './image-card-list.component.html'
})
export class ImageCardListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
