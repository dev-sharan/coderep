import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-side-video',
  templateUrl: './blog-side-video.component.html'
})
export class BlogSideVideoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
