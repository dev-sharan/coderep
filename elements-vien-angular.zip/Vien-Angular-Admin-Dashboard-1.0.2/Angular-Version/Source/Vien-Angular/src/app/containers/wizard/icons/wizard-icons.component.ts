import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-icons',
  templateUrl: './wizard-icons.component.html'
})
export class WizardIconsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
