import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-process',
  templateUrl: './profile-process.component.html'
})
export class ProfileProcessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
