import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-is-error',
  templateUrl: './page-is-error.component.html',
  styleUrls: ['./page-is-error.component.css']
})
export class PageIsErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
