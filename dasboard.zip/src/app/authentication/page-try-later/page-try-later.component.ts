import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-try-later',
  templateUrl: './page-try-later.component.html',
  styleUrls: ['./page-try-later.component.css']
})
export class PageTryLaterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
